﻿using System;

namespace TeilenDurchNull
{
  class Program
  {
    static void Main(string[] args)
    {
      int x = 7;
      int y = 0;

      x /= y;
    }
  }
}