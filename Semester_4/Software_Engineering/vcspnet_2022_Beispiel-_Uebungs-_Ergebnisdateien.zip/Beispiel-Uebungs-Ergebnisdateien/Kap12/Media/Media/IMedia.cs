using System;

namespace Media
{
  interface IMedia
  {
    string DisplayMedia();

    string PlayMedia();

    string StopMedia();
  }
}
