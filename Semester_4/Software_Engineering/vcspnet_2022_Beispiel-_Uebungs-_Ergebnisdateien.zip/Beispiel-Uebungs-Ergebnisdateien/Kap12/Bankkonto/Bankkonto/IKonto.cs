using System;

namespace Bankkonto
{
  interface IKonto
  {
    double Kontostand { get; set; }
  }
}
