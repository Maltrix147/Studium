﻿using System;

namespace HalloWelt
{
  class Program
  {
    static void Main(string[] args)
    {
      Console.WriteLine("Hallo Welt!");
    }
  }
}