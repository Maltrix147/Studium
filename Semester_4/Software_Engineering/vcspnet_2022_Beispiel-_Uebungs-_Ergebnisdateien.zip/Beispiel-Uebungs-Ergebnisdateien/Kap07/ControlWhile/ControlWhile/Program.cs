﻿using System;

namespace ControlWhile
{
  class Program
  {
    static void Main(string[] args)
    {
      int i = 1;

      while (i < 10)
      {
        Console.WriteLine(i);
        i += 1;
      }
    }
  }
}