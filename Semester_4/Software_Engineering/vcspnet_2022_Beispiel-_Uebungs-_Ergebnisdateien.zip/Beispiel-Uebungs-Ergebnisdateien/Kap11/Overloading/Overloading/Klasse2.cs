using System;

namespace Overloading
{
  class Klasse2 : Klasse1
  {
    public override string Test()
    {
      return "Die Methode Klasse2.Test wurde ohne Parameter aufgerufen.";
    }
  }
}
