﻿using System;

namespace Zahlen2
{
  class Program
  {
    static void Main(string[] args)
    {
      Zahl2 eineZahl = new Zahl2();

      eineZahl.Eingabe(10);
      eineZahl.Ausgabe();
    }
  }
}