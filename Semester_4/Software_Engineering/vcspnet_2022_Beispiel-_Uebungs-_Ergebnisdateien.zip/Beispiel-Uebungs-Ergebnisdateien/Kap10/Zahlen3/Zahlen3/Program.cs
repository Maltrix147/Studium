﻿using System;

namespace Zahlen3
{
  class Program
  {
    static void Main(string[] args)
    {
    }
  }
}