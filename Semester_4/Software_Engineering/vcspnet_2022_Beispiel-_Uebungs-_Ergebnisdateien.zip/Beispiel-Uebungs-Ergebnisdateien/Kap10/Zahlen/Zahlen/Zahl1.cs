using System;

namespace Zahlen
{
  class Zahl1
  {
    protected int wert;

    public void Ausgabe()
    {
      Console.WriteLine(this.wert);
    }
  }
}
