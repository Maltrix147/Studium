using System;

namespace Zahlen
{
  class Zahl2 : Zahl1
  {
    public void Eingabe(int i)
    {
      this.wert = i;
    }
  }
}
